-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: mysql
-- Generation Time: Apr 30, 2018 at 03:11 PM
-- Server version: 5.7.22
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `khadamati-ai`
--

-- --------------------------------------------------------

--
-- Table structure for table `all_words`
--

CREATE TABLE `all_words` (
  `id` int(10) UNSIGNED NOT NULL,
  `dialect_id` int(10) UNSIGNED NOT NULL,
  `nature_id` int(10) UNSIGNED NOT NULL,
  `word` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `all_words`
--

INSERT INTO `all_words` (`id`, `dialect_id`, `nature_id`, `word`, `created_at`, `updated_at`) VALUES
(1, 3, 2, 'anaya', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(2, 3, 1, 'nebghi', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(3, 3, 1, 'nel3ab', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(4, 3, 2, 'korat', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(5, 3, 2, 'elkadam', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(6, 2, 2, 'أنا', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(7, 2, 1, 'أحب', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(8, 2, 1, 'لعب', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(9, 2, 2, 'كرة', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(10, 2, 2, 'القدم', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(11, 2, 2, 'النفط', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(12, 2, 2, 'يرتفع', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(13, 2, 2, 'قرب', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(14, 2, 2, 'دولاراً', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(15, 2, 2, 'إلى', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(16, 2, 2, 'أعلى', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(17, 2, 2, 'مستوى', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(19, 2, 2, 'منذ', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(20, 2, 2, 'أواخر', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(21, 2, 2, 'الشهر', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(22, 3, 2, 'el-nepht', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(23, 3, 2, '9laa', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(24, 3, 2, 'krub', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(25, 3, 2, 'dolar', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(26, 3, 2, 'le', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(27, 3, 2, '3aali', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(28, 3, 2, 'nivou', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(29, 3, 2, 'men', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(30, 3, 2, 'aakhir', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(31, 3, 2, 'el-chehar', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(32, 2, 2, 'نتائج', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(33, 2, 2, 'قوية', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(34, 2, 2, 'للشركات', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(36, 2, 2, 'تصعد', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(37, 2, 2, 'بالأسهم', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(38, 2, 2, 'الأميركية', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(39, 2, 2, 'ب', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(40, 3, 2, 'resultat', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(41, 3, 2, 'kouwat', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(42, 3, 2, 'charikat', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(43, 3, 2, 'tal3at', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(44, 3, 2, 'bel', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(45, 3, 2, 'asshoum', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(46, 3, 2, 'marikania', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(47, 2, 2, 'الذهب', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(48, 2, 2, 'يرتفع', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(49, 2, 2, 'ل', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(50, 2, 2, 'الجلسة', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(51, 2, 2, 'الخامسة', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(52, 3, 2, 'dhab', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(53, 3, 2, '3la', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(54, 3, 2, 'lel', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(55, 3, 2, 'djelssa', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(56, 3, 2, 'lkhamssa', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(57, 3, 2, 'khamssin', NULL, NULL),
(58, 2, 2, 'خمسون', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `definition`
--

CREATE TABLE `definition` (
  `id` int(10) UNSIGNED NOT NULL,
  `word_id` int(10) UNSIGNED NOT NULL,
  `definition` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `definition`
--

INSERT INTO `definition` (`id`, `word_id`, `definition`, `created_at`, `updated_at`) VALUES
(1, 33, 'قوي (مقاييس اللغة)\r\n\r\nالقاف والواو والياء أصلانِ متباينان، يدلُّ أحدُهما على شِدَّة وخِلافِ ضَعْف، والآخَر على خلافِ هذا وعلى قِلّة خَيْر.فالأوَّل القُوّة، والقوِيّ: خلاف الضّعيف.\r\nوأصل ذلك من القُوَى، وهيجَمْعُ قوةٍ من قُوَى الحبل.\r\nوالمُقْوِي الذي أصحابُه وإبلُه أقوياء.\r\nوالمُقْوِي الذي يُقْوِي وَتَرَه، إذا لم يُجِدْ إغارتَه فتراكبَتْ قُواه.\r\nورجلٌ شديد القُوى، أي شديدُ أسْرِ الخَلْق.فأمَّا قولهم: أقوى الرّجُلُ في شِعره، فهو أن يَنْقُص من عروضه قُوّة. كقوله:\r\nأفَبَعْدَ مقتلِ مالكِ بن زُهَيْرٍ    يرجو النِّساءُ عواقبَ الأطهارِ', NULL, NULL),
(2, 12, 'نمي (لسان العرب)\r\nالنَّماءُ: الزيادة. نَمَى يَنْمِي نَمْياً ونُمِيّاً ونَماءَ: زاد وكثر، وربما قالوا يَنْمُو نُمُوًّا. المحكم: قال أَبو عبيد قال الكسائي ولم أَسمع يَنْمُو، بالواو، إِلا من أَخَوين من بني سليم، قال: ثم سأَلت عنه جماعة بني سليم فلم يعرفوه بالواو؛ قال ابن سيده: هذا قول أَبي عبيد، وأَما يعقوب فقال يَنْمى ويَنْمُو فسوَّى بينهما، وهي النَّمْوة، وأَنْماه الله إِنْماءً. قال ابن بري: ويقال نَماه اللهُ، فيعدّى بغير همزة، ونَمَّاه، فيعدِّيه بالتضعيف؛ قال الأَعور الشَّنِّي، وقيل: ابن خَذَّاق:لقَدْ عَلِمَتْ عَمِيرةُ أَنَّ جارِي، إِذا ضَنَّ المُنَمِّي، من عِيالي وأَنْمَيْتُ الشيءَ ونَمَّيْته: جعلته نامياً.\r\nوفي الحديث: أَن رجلاً أَراد الخروج إِلى تَبُوكَ فقالت له أُمه أَو امرأَته كيف بالوَدِيِّ؟ فقال: الغَزْوُ أَنْمَى للوَدِيِّ أَي يُنَمِّيه الله للغازي ويُحْسن خِلافته عليه.\r\nوالأَشياءُ كلُّها على وجه الأَرض نامٍ وصامِتٌ: فالنَّامي مثل النبات والشجر ونحوِه، والصامتُ كالحجَر والجبل ونحوه.\r\nونَمَى الحديثُ يَنْمِي: ارتفع.', NULL, NULL),
(3, 32, 'نتج (لسان العرب)\r\nالنِّتاجُ: اسم يَجْمع وضْعَ جميعِ البهائِمِ؛ قال بعضهم: هو في الناقة والفرس، وهو فيما سِوى ذلك نَتج، والأَول أَصح؛ وقيل: النِّتاجُ في جميع الدَّوابِّ، والوِلادُ في الغنم، وإِذا وَليَ الرجلُ ناقةً ماخِضاً ونِتاجَها حتى تضع، قيل: نَتَجها نَتْجاً. يقال: نَتَجْتُ الناقةَ (* قوله «نتجت الناقة إلخ» هو من باب ضرب كما في المصباح.', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `dialect`
--

CREATE TABLE `dialect` (
  `id` int(10) UNSIGNED NOT NULL,
  `dialect` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `dialect`
--

INSERT INTO `dialect` (`id`, `dialect`, `created_at`, `updated_at`) VALUES
(1, 'gulf', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(2, 'standard', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(3, 'algerian', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(4, 'saudi', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(5, 'egyptian', '2018-04-29 00:00:00', '2018-04-29 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2018_04_23_210140_create_nature_table', 1),
(4, '2018_04_23_210610_create_dialect_table', 1),
(5, '2018_04_23_210638_create_all-words_table', 1),
(6, '2018_04_23_210650_create_translation_table', 1),
(7, '2018_04_23_212125_create_definition_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `nature`
--

CREATE TABLE `nature` (
  `id` int(10) UNSIGNED NOT NULL,
  `nature` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nature`
--

INSERT INTO `nature` (`id`, `nature`, `created_at`, `updated_at`) VALUES
(1, 'verb', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(2, 'noun', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(3, 'adjective', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(4, 'adverb', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(5, 'determinative', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(6, 'preposition', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(7, 'coordinator', '2018-04-29 00:00:00', '2018-04-29 00:00:00'),
(8, 'subordinator', '2018-04-29 00:00:00', '2018-04-29 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `translation`
--

CREATE TABLE `translation` (
  `id` int(10) UNSIGNED NOT NULL,
  `word_id1` int(10) UNSIGNED NOT NULL,
  `word_id2` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `translation`
--

INSERT INTO `translation` (`id`, `word_id1`, `word_id2`, `created_at`, `updated_at`) VALUES
(1, 22, 11, NULL, NULL),
(2, 23, 12, NULL, NULL),
(3, 24, 13, NULL, NULL),
(5, 26, 15, NULL, NULL),
(6, 53, 16, NULL, NULL),
(7, 28, 17, NULL, NULL),
(8, 29, 19, NULL, NULL),
(9, 30, 20, NULL, NULL),
(10, 31, 21, NULL, NULL),
(11, 40, 32, NULL, NULL),
(12, 41, 33, NULL, NULL),
(13, 42, 34, NULL, NULL),
(14, 43, 36, NULL, NULL),
(15, 45, 37, NULL, NULL),
(16, 46, 38, NULL, NULL),
(17, 52, 47, NULL, NULL),
(18, 55, 50, NULL, NULL),
(19, 56, 51, NULL, NULL),
(20, 57, 58, NULL, NULL),
(21, 25, 14, NULL, NULL),
(22, 25, 14, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `all_words`
--
ALTER TABLE `all_words`
  ADD PRIMARY KEY (`id`),
  ADD KEY `all_words_dialect_id_foreign` (`dialect_id`),
  ADD KEY `all_words_nature_id_foreign` (`nature_id`);

--
-- Indexes for table `definition`
--
ALTER TABLE `definition`
  ADD PRIMARY KEY (`id`),
  ADD KEY `definition_word_id_foreign` (`word_id`);

--
-- Indexes for table `dialect`
--
ALTER TABLE `dialect`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nature`
--
ALTER TABLE `nature`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `translation`
--
ALTER TABLE `translation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `translation_word_id1_foreign` (`word_id1`),
  ADD KEY `translation_word_id2_foreign` (`word_id2`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `all_words`
--
ALTER TABLE `all_words`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `definition`
--
ALTER TABLE `definition`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `dialect`
--
ALTER TABLE `dialect`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `nature`
--
ALTER TABLE `nature`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `translation`
--
ALTER TABLE `translation`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `all_words`
--
ALTER TABLE `all_words`
  ADD CONSTRAINT `all_words_dialect_id_foreign` FOREIGN KEY (`dialect_id`) REFERENCES `dialect` (`id`),
  ADD CONSTRAINT `all_words_nature_id_foreign` FOREIGN KEY (`nature_id`) REFERENCES `nature` (`id`);

--
-- Constraints for table `definition`
--
ALTER TABLE `definition`
  ADD CONSTRAINT `definition_word_id_foreign` FOREIGN KEY (`word_id`) REFERENCES `all_words` (`id`);

--
-- Constraints for table `translation`
--
ALTER TABLE `translation`
  ADD CONSTRAINT `translation_word_id1_foreign` FOREIGN KEY (`word_id1`) REFERENCES `all_words` (`id`),
  ADD CONSTRAINT `translation_word_id2_foreign` FOREIGN KEY (`word_id2`) REFERENCES `all_words` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
